class DevelopmentConfig():
    DEBUG = True

    SECRET_KEY = "qhrf$edjYTJ)*21nsThdK"
    MYSQL_HOST = "localhost"
    MYSQL_USER = "root"
    MYSQL_PASSWORD = "0000"
    MYSQL_DB = "store"